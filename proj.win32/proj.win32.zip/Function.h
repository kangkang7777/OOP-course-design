#ifndef _Function_H_
#define _Function_H_


//store some functions created by myself

#include "Function.cpp"

#endif